<?php
$manifest = array (
  'acceptable_sugar_versions' => 
  array (
    'regex_matches' => 
    array (
      0 => '10.*.*',
      1 => '11.*.*',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'ENT',
    1 => 'PRO',
    2 => 'SELL',
    3 => 'SERVE',
  ),
  'readme' => '',
  'key' => '20210927',
  'author' => 'Lampada Global',
  'description' => 'Engage enum based powerful custom field types in order to simplify complex data set loading from database',
  'icon' => '',
  'is_uninstallable' => true,
  'name' => 'EnumApiField Family',
  'built_in_version' => '11.1.0-dev.1',
  'published_date' => '2021-09-21 15:58:12',
  'type' => 'module',
  'version' => '1.0.0',
  'remove_tables' => 'prompt',
);
$installdefs = array (
  'id' => 'enum-api',
  'beans' => 
  array (
  ),
  'language' => 
  array (
  ),
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/custom/clients/base/fields/enum-api/',
      'to' => 'custom/clients/base/fields/enum-api/',
    ),
    1 => 
    array (
      'from' => '<basepath>/custom/clients/base/fields/enum-mult-parent-api/',
      'to' => 'custom/clients/base/fields/enum-mult-parent-api/',
    ),
    2 => 
    array (
      'from' => '<basepath>/custom/clients/base/fields/enum-parent-api/',
      'to' => 'custom/clients/base/fields/enum-parent-api/',
    ),
  ),
  'custom_fields' => 
  array (
  ),
);
